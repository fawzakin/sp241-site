---
permalink: /LINKS/
---

# LINKS

1. [Hugo](https://gohugo.io/)<br>
The better Jekyll written in Go.
Seriously, why don't we use Hugo isntead? It's much faster to compile, quicker to install, and easier to write theme for.

2. [Godot](https://godotengine.org/)<br>
The best FOSS game engine, perfect for everyone from indie to big companies.
I'm taking gamedev class which has massive project I'm partaking for and we're using Godot like everybody else! 

3. [Rainbow Dash](https://mlp.fandom.com/wiki/Rainbow_Dash)<br>
My favorite pony ^^ and I don't know what else to add lol. Please don't ask why I choose Twilight for the banner image instead of RD.


