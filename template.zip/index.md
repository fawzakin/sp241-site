---
---

[&#x213C;](#idxXXX)<br id="idx000">
# {{ site.title }}

Welcome abroad! I am {{ site.author }}, {{ site.address }}

Feel free to look around, I guess. All the important link will be put in the table of links!

I may write articles like what I did for OS class depending on my mood and my time so who knows lol.

**Please disable dark mode pages from your browser or your plugins. This site is already in dark mode and it'll break the styling color!**

[&#x213C;](#)<br id="idx002">
## Table of Links 

| [HOME]({{ site.baseurl }}/) | [LISTINGS]({{ site.baseurl }}/000.html) | [LINKS]({{ site.baseurl }}/LINKS/) |
| [TIPS]({{ site.baseurl }}/TIPS/) | [TARBALL]({{ site.baseurl }}/template.tar.xz) | [ZIP File]({{ site.baseurl }}/template.zip) |
| [GitHub]({{ site.urlgithub }}) | [ABOUT]({{ site.baseurl }}/ABOUT/) | [WEB]({{ site.urlweb }}) |

[&#x213C;](#)<br id="idx003">
### More Links

* [My previous page for OS212 class](https://fawzakin.github.io/os212/)
* [Original source of the header image](https://derpibooru.org/images/2844312)
* [GitHub Page with no Jekyll Theme](https://doit.vlsm.org/001.html)
* [Installing Jekyll on a VirtualBox](https://doit.vlsm.org/005.html)
* [This is how I copy someone to do it!](https://doit.vlsm.org/)

[&#x213C;](#)<br id="idxXXX">

