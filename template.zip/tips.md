---
permalink: /TIPS/
---

# TIPS

1. Be an egghead lmao <br>
